#include <fstream>
#include <iostream>
#include <stdio.h>
#include <io.h>
#include <string>
#include <winsock2.h>
#include <bits/stdc++.h>
#include <Ws2tcpip.h>

using namespace std;

#define SERVER "127.0.0.1"
#define PORT 8888

int main() {
    
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[1024] = {0};

    while (1) {
        cout << "Input: ";
        string input;
        getline(cin, input);

        sock = socket(AF_INET, SOCK_STREAM, 0);
        serv_addr.sin_family = AF_INET;
        serv_addr.sin_port = htons(PORT);
        inet_pton(AF_INET, SERVER, &serv_addr.sin_addr);


    }
    

    return 0;
}